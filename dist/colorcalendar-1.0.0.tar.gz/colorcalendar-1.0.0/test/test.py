from colorcalendar.main import main

main()
